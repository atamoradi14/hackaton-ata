# Codex instructions pack — Auckland property hydraulic digital twin

This package contains a detailed **implementation plan**, not a working simulation and not downloaded GIS data.

## Start with Codex
1. Create a **private** empty Git repository or local folder.
2. Copy these files to its root.
3. Open Codex in the root and paste:

   > Read AGENTS.md, CODEX_MASTER_PLAN.md, SOURCES.md and config.example.yaml in full. Begin implementing the G0 milestone with a working offline synthetic 2D SFINCS physics test, `floodtwin doctor` and robust Council ArcGIS metadata introspection. Use a real solver, no fake flood outputs. Track progress in PROGRESS.md and request access keys or data only when required. Continue through milestones G1–G7 with tests and provenance gates.

4. Get a LINZ Data Service key, verify the target address, inspect coverage and obtain correct HIRDS rain event data **before running site-specific claims**.
5. See CODEX_MASTER_PLAN.md for deliverables, full modelling constraints, CLI specifications, workflow and acceptance criteria.

## Terms
- GIS flow trace != hydraulic 2D solver output.
- A point cloud / 1m DEM != automatically detected real fences.
- Drainage GIS lines != validated pressurised pipe network.
- The home address has **not** been geocoded or tested by this plan.
- Site results are research-grade unless calibrated and signed off by a qualified engineer.
